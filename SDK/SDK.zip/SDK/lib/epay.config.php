<?php
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = 'https://www.sdezf.com/';

//商户ID
$epay_config['pid'] = '1206';

//商户密钥
$epay_config['key'] = 'u68JM77178284e07682S6Jjj7J4mja2a';
